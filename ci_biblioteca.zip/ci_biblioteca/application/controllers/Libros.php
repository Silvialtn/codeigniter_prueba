
<?php


class Libros extends CI_controller{

	public function __construct(){

		parent::__construct();
		$this->load->helper('form');
		$this->load->helper("url");
		$this->load->model('Libro');
		$this->load->library('form_validation');
		$this->load->database();


	}

	function index(){


		 redirect("/libros/listado"); // redireccionar

	}


	public function listado($pag = 1){

		$pag--;
		if($pag < 0 ){
		$pag = 0;
		}

		 $page_size = 5;
		 $offset = $pag * $page_size;

			
	
		$vdata["libros"]= $this->Libro->pagination($page_size,$offset);
		$vdata["current_pag"] = $pag+1;
		$vdata["last_page"] = ceil($this->Libro->count() / $page_size);


		
		//	$vdata["libros"]=$this->Libro->findAll();
		$this->load->view('libros/listado', $vdata); // enlazamos la vista



	}


	public function guardar($libro_id = null){

		//VALIDACION
		$this->form_validation->set_rules('nombre', 'Nombre', 'required|min_length[3]');
		$this->form_validation->set_rules('autor', 'Autor', 'required');
		$this->form_validation->set_rules('categoria', 'Categoria', 'required');
		$this->form_validation->set_rules('fecha', 'Fecha', 'required');
		$this->form_validation->set_rules('usuario', 'Usuario', 'required');

		$vdata["nombre"]=$vdata["autor"]=$vdata["categoria_id"]=$vdata["fecha_publicacion"]=$vdata["usuario_id"]= "";

		if(isset($libro_id)){

			//BUSCAMOS EL REGISTRO	
			$libro = $this->Libro->find($libro_id);

			if(isset($libro)){
				//se forma la data como se requiere desde el registro encontrado
				$vdata["nombre"]= $libro->nombre;
				$vdata["autor"]= $libro->autor;
				$vdata["categoria_id"]= $libro->categoria_id;
				$vdata["fecha_publicacion"]= $libro->fecha_publicacion;
				$vdata["usuario_id"]= $libro->usuario_id;
			}

		}
		//VERIFICAMOS QUE VENGA CON EL METODO POST
		if($this->input->server("REQUEST_METHOD")=="POST"){

			//se forma la data como se requiere

			$data["nombre"]= $this->input->post("nombre");
			$data["autor"]=$this->input->post("autor");
			$data["categoria_id"]= $this->input->post("categoria");
			$data["fecha_publicacion"]= $this->input->post("fecha");
			$data["usuario_id"]= $this->input->post("usuario");
		
			$vdata["nombre"]= $this->input->post("nombre");
			$vdata["autor"]=$this->input->post("autor");
			$vdata["categoria_id"]= $this->input->post("categoria");
			$vdata["fecha_publicacion"]= $this->input->post("fecha");
			$vdata["usuario_id"]= $this->input->post("usuario");
		

			if ($this->form_validation->run()){ // VALIDA SI EL FORMULARIO ES VALIDO
				if(isset($libro_id)){
				 // actualiza
				$this->Libro->update($libro_id, $data);
				}else // se inserta
				$this->Libro->insert($data);
			}
			
		}

		$this->load->view('libros/guardar', $vdata); // enlazamos la vista
	}



	public function borrar($libro_id =  null){

		 $this->Libro->delete($libro_id);
		 redirect("/libros/listado"); // redireccionar

	}


	public function ver($libro_id = null){

			if(!isset($libro_id)){

				show_404();
			}

			//BUSCAMOS EL REGISTRO	
			$libro = $this->Libro->find($libro_id);

			if(!isset($libro)){

				show_404();
			}

			if(isset($libro)){
				//se forma la data como se requiere desde el registro encontrado
				$vdata["nombre"]= $libro->nombre;
				$vdata["autor"]= $libro->autor;
				$vdata["categoria_id"]= $libro->categoria_id;
				$vdata["fecha_publicacion"]= $libro->fecha_publicacion;
				$vdata["usuario_id"]= $libro->usuario_id;
			}else{	
				$vdata["nombre"]=$vdata["autor"]=$vdata["categoria_id"]=$vdata["fecha_publicacion"]=$vdata["usuario_id"]= "";
			}

			$this->load->view('libros/ver', $vdata); // enlazamos la vista
	}



}



?>
