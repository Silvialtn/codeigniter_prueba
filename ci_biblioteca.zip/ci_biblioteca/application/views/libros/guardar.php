<html>
	<HEAD>
		
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	</HEAD>
	<body>

	<!-- se engloba en un cointainer-->	
	<div class="container">


      <br>
      <a href="<?php echo base_url() ?>libros/listado" class="btn btn-success">Regresar</a>
      <br><br>


	<!-- PARA MOSTRAR ERRORES DE VALIDACION-->		
	<?php echo validation_errors(); ?>
	<!-- abrir el formulario -->	
	<?php echo form_open(''); ?>		
	<div class="form-group">
			<?php
			
			
			echo form_label('Disponibilidad', 'status');
			// se define el input
			$input =  array(
				        'name'          => 'status',
				        
				        'value'         => 'Disponibilidad',
				        'checked'       => TRUE,
				        'style'         => 'margin:10px'
				);


			// se imprime

			echo form_checkbox($input);

			  ?>

		</div>



		<div class="form-group">
			<?php
			//se define el label texto / atributo form
			echo form_label('Nombre', 'nombre');
			// se define el input
			$input = array(
			        'name'  => 'nombre',
			        'value' => $nombre,
			        'class' => 'form-control input-lg'
			);

			// se imprime
			echo form_input($input);


			  ?>

		</div>
		<div class="form-group">
			<?php
			//se define el label texto / atributo form
			echo form_label('Autor', 'autor');
			// se define el input
			$input = array(
			        'name'  => 'autor',
			        'value' => $autor,
			        'class' => 'form-control input-lg'
			);

			// se imprime
			echo form_input($input);


			  ?>

		</div>
		<!-- div class="form-group">
			<?php

			/*
			//se define el label texto / atributo form
			echo form_label('Categoria', 'categoria');
			// se define el input
			$input = array(
			        'name'  => 'categoria',
			        
			        'value' => $categoria_id,
			        'class' => 'form-control input-lg'
			);

			// se imprime
			echo form_input($input);

*/
			  ?>

		</div-->
		<div class="form-group">
			<?php
			//se define el label texto / atributo form
			echo form_label('Categoria', 'categoria');

			$categorias = $this->Libro->findAllCat();

			//print_r($categorias);


			// se define el input
			$options = array(
			        '1'         => 'negocios',
			        '2'           => 'novela',
			        '3'         => 'bibliografi',
			        '4'        => 'diseño',
			);
			// se imprime
			echo form_dropdown('categoria', $options, 'large');


			  ?>




		<div class="form-group">
			<?php
			//se define el label texto / atributo form
			echo form_label('Fecha', 'fecha');
			// se define el input
			$input = array(
			        'name'  => 'fecha',
			        'type'=>'date',
			        
			        'value' => $fecha_publicacion,
			        'class' => 'form-control input-lg'
			);

			// se imprime
			echo form_input($input);


			  ?>

		</div>	

		<div class="form-group">
			<?php
			//se define el label texto / atributo form
			echo form_label('Usuario', 'usuario');
			// se define el input
			$input = array(
			        'name'  => 'usuario',
			        
			        'value' => $usuario_id,
			        'class' => 'form-control input-lg'
			);

			// se imprime
			echo form_input($input);


			  ?>

		</div>
		</div>


	<?php 

	echo form_submit('mysubmit', 'Enviar',"class='btn btn-primary'");
	?>

	<!--cerrar el formulario -->
	<?php echo form_close(); ?>
	</div>
	</body>

</html>