<html>
	<HEAD>
		
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	</HEAD>
	<body>

	<!-- se engloba en un cointainer-->	
	<div class="container">


      <br>
      <a href="../listado" class="btn btn-success">Regresar</a>
      <br><br>



	<!-- abrir el formulario -->	
	<?php echo form_open(''); ?>

		<div class="form-group">
			<?php
			//se define el label texto / atributo form
			echo form_label('Nombre', 'nombre');
			// se define el input
			$input = array(
			        'name'  => 'nombre',
			        'readonly'=>'readonly',
			        'value' => $nombre,
			        'class' => 'form-control input-lg'
			);

			// se imprime
			echo form_input($input);


			  ?>

		</div>
		<div class="form-group">
			<?php
			//se define el label texto / atributo form
			echo form_label('Autor', 'autor');
			// se define el input
			$input = array(
			        'name'  => 'autor',
			         'readonly'=>'readonly',
			        'value' => $autor,
			        'class' => 'form-control input-lg'
			);

			// se imprime
			echo form_input($input);


			  ?>

		</div>
		<div class="form-group">
			<?php
			//se define el label texto / atributo form
			echo form_label('Categoria', 'categoria');
			// se define el input
			$input = array(
			        'name'  => 'categoria',
			         'readonly'=>'readonly',
			        'value' => $categoria_id,
			        'class' => 'form-control input-lg'
			);

			// se imprime
			echo form_input($input);


			  ?>
		<div class="form-group">
			<?php
			//se define el label texto / atributo form
			echo form_label('Fecha', 'fecha');
			// se define el input
			$input = array(
			        'name'  => 'fecha',
			         'readonly'=>'readonly',
			        'value' => $fecha_publicacion,
			        'class' => 'form-control input-lg'
			);

			// se imprime
			echo form_input($input);


			  ?>

		</div>		
		<div class="form-group">
			<?php
			//se define el label texto / atributo form
			echo form_label('Usuario', 'usuario');
			// se define el input
			$input = array(
			        'name'  => 'usuario',
			         'readonly'=>'readonly',
			        'value' => $usuario_id,
			        'class' => 'form-control input-lg'
			);

			// se imprime
			echo form_input($input);


			  ?>

		</div>
		</div>


	<!--cerrar el formulario -->
	<?php echo form_close(); ?>
	</div>
	</body>

</html>