<?php 
// Desactivar toda notificación de error
error_reporting(0);
 
// Notificar solamente errores de ejecución
error_reporting(E_ERROR | E_WARNING | E_PARSE)
?>
<html>
  <HEAD>
    
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </HEAD>
  <body>
    <div  class="container">
      <br>
      <a href="guardar" class="btn btn-success">Guardar</a>
      <br><br>

<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Nombre</th>
      <th scope="col">Disponibilidad</th>
      <th scope="col">Autor</th>
      <th scope="col">Categoria</th>
      <th scope="col">Fecha publicación</th>
      <th scope="col">Usuario</th>

      <th scope="col">Acciones</th>
    </tr>
  </thead>
  <tbody>
<?php foreach ($libros as $key => $l) :?>

    <tr>
      <th scope="row"><?php echo $l->libro_id ?></th>
      <td><?php echo $l->nombre ?></td>
      <td><?php echo $l->status ?></td>
      <td><?php echo $l->autor ?></td>
      <td><?php echo $l->categoria_id ?></td>
      <td><?php echo $l->fecha_publicacion ?></td>
      <td><?php echo $l->usuario_id ?></td>


      <td>
        <a href="guardar/<?php echo $l->libro_id ?>"> Editar</a>
        <br>
        <a href="ver/<?php echo $l->libro_id ?>">Ver</a>
        <br>
        <a href="borrar/<?php echo $l->libro_id ?>">Borrar</a>
        
      </td>
    </tr>
 <?php endforeach; ?>
  </tbody>

<nav aria-label="Page navigation example">
  <ul class="pagination">

<?php
$prev= $current_pag-1;
$next = $current_pag+1;

if($prev <= 0 ){

  $prev = 1;
}
if($next > $last_page){

  $next = $last_page;
}


?>

    <li class="page-item"><a class="page-link" href="<?php echo base_url()."libros/listado/".$prev ?>">Previous</a></li>
    <?php for($i=1; $i<=$last_page; $i++){ ?>
    <li class="page-item"><a class="page-link" href="<?php echo base_url()."libros/listado/".$i ?>"><?php echo $i?></a></li>
  <?php } ?>

    <li class="page-item"><a class="page-link" href="<?php echo base_url()."libros/listado/".$next ?>">Next</a></li>
  </ul>
</nav>

</table>
  </div>
  </body>

</html>