<?php

class Libro extends CI_Model {

//variables globales
public $table = 'libros';
public $table_id = 'libro_id';
public $table_cat = 'categorias';

//constructor
public function __construct(){



}

//funcion encontrar un registro 
function find($id){


	$this->db->select(); // accion a hacer 
	$this->db->from($this->table); // indicar la tabla
	$this->db-> where($this->table_id, $id); // definir el where

	$query = $this->db->get(); //obtenemos los resultados
	return $query->row(); //indicamos retornar solo una fila

}


//funcion encontrar todos los registros 
function findAll(){


	$this->db->select(); // accion a hacer 
	$this->db->from($this->table); // indicar la tabla
	

	$query = $this->db->get(); //obtenemos los resultados
	return $query->result(); //indicamos retornar solo una fila

}


//funcion encontrar todos los registros 
function findAllCat(){


	$this->db->select('categoria_id, nombre'); // accion a hacer 
	$this->db->from($this->table_cat); // indicar la tabla
	

	$query = $this->db->get(); //obtenemos los resultados
	return $query->result(); //indicamos retornar solo una fila

}


//funcion encontrar todos los registros 
function pagination($page_size, $offset){


	$this->db->select(); // accion a hacer 
	$this->db->from($this->table); // indicar la tabla

	$this->db->limit($page_size, $offset); //limite
	

	$query = $this->db->get(); //obtenemos los resultados
	return $query->result(); //indicamos retornar solo una fila

}

//funcion contar
function count(){


	$this->db->select(); // accion a hacer 
	$this->db->from($this->table); // indicar la tabla
	

	$query = $this->db->get(); //obtenemos los resultados
	return $query->num_rows(); //indicamos retornar solo una fila

}





function insert($data){
	$this->db->insert($this->table, $data);
	return $this->db->insert_id();
}

function update($id, $data){
	$this->db->where($this->table_id, $id); 
	$this->db->update($this->table, $data);


}

function delete($id){
	$this->db->where($this->table_id, $id);
	$this->db->delete($this->table);


}


}

?>